-- MySQL dump 10.19  Distrib 10.3.37-MariaDB, for Win64 (AMD64)
--
-- Host: i8b301.p.ssafy.io    Database: bora
-- ------------------------------------------------------
-- Server version	10.3.37-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `storybox`
--

DROP TABLE IF EXISTS `storybox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storybox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contents` varchar(2048) DEFAULT NULL,
  `is_delete` bit(1) NOT NULL,
  `is_read` bit(1) NOT NULL,
  `reg_date_time` datetime(6) DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `viewer_id` varchar(32) DEFAULT NULL,
  `dj_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8mkc618qm6dw5vd7d9qlufs9a` (`dj_id`),
  CONSTRAINT `FK8mkc618qm6dw5vd7d9qlufs9a` FOREIGN KEY (`dj_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storybox`
--

LOCK TABLES `storybox` WRITE;
/*!40000 ALTER TABLE `storybox` DISABLE KEYS */;
INSERT INTO `storybox` VALUES (1,'내용입니다','','\0','2023-02-15 20:15:24.174448','제목입니다',NULL,'3'),(2,'사연내용내용22','','\0','2023-02-16 01:26:58.210033','사연제목22','2','3'),(5,'사연내용내용2','','','2023-02-16 17:38:56.709595','사연제목2','102','1'),(6,'69514','','\0','2023-02-16 17:46:50.671525','5616','eodms090@naver.com','3'),(8,'안녕하세요','','','2023-02-17 01:49:26.000000','제이름은1이에요','1','swyh0625@naver.com'),(9,'안녕하세요','','','2023-02-17 01:49:54.000000','제이름은2에요','2','swyh0625@naver.com'),(10,'안녕하세요','','','2023-02-17 01:50:03.000000','제이름은3이에요','3','swyh0625@naver.com'),(11,'안녕하세요','\0','\0','2023-02-17 01:50:14.000000','제이름은4에요','4','swyh0625@naver.com'),(12,'안녕하세요','\0','\0','2023-02-17 01:50:22.000000','제이름은5에요','5','swyh0625@naver.com'),(13,'안녕하세요','\0','','2023-02-17 01:50:30.000000','제이름은6이에요','6','swyh0625@naver.com'),(18,'sdfsdfds','\0','\0','2023-02-17 03:04:40.513589','sdfsdf','kk980626@daum.net','3'),(19,'asdfasdfddddd','\0','\0','2023-02-17 04:29:43.162638','asdfdddd','swyh0625@naver.com','3'),(20,'asd','\0','\0','2023-02-16 21:20:02.962181','asd','eodms090@naver.com','3');
/*!40000 ALTER TABLE `storybox` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:26:10

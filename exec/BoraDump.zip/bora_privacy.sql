-- MySQL dump 10.19  Distrib 10.3.37-MariaDB, for Win64 (AMD64)
--
-- Host: i8b301.p.ssafy.io    Database: bora
-- ------------------------------------------------------
-- Server version	10.3.37-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `privacy`
--

DROP TABLE IF EXISTS `privacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privacy` (
  `user_id` varchar(32) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `FKtpah0mj1fauronulg7m9bdq6g` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privacy`
--

LOCK TABLES `privacy` WRITE;
/*!40000 ALTER TABLE `privacy` DISABLE KEYS */;
INSERT INTO `privacy` VALUES ('email',1,'f',NULL),('eodms090@naver.com',2,'f','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJpc3N1ZXIiLCJpYXQiOjE2NzY0OTE5NzAsImV4cCI6MTY3NzA5Njc3MH0.Ui-q4L9Li6cHV-zHlh-Jor-Sv2Wws-XjtoUpIe_hfxgPGetfX_Xav82Bcw4iUkNi-HcGUKM_ByF7Fj0ijuBxpg'),('kk980626@daum.net',2,'f','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJpc3N1ZXIiLCJpYXQiOjE2NzY1MzQwNDEsImV4cCI6MTY3NzEzODg0MX0.l_atCKksk5pYg39iyQBumkWQ1yenWCfh2NfrAFM2T9OQR1tVEXChLMiIv-YilsoAZbPcuZk-dt0HqBq8kA_ohw'),('ksw',3,'m',NULL),('lsms3723@daum.net',0,NULL,'eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJpc3N1ZXIiLCJpYXQiOjE2NzY1MzYzOTQsImV4cCI6MTY3NzE0MTE5NH0.NAOoUbChBGRuVoGN4qCUq-4j9n-MMctvzPfQreHbgl7ANPA1UWso5YXkrM2JCrQbolx8Y155aAN2NxAbzKQ7xw'),('swyh0625@naver.com',3,'f','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJpc3N1ZXIiLCJpYXQiOjE2NzY1MTMwNTcsImV4cCI6MTY3NzExNzg1N30.ZKW4bwUZ-UgqkjlNkUKSvZnt7E3V_V0sHqw_suMm8lBqWq1Q3gz2bXfZZ2L0z9y_ywfFD89U32c4_K8tsnWfhA'),('yyh6290@naver.com',1,'m','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJpc3N1ZXIiLCJpYXQiOjE2NzY1MzYyNzgsImV4cCI6MTY3NzE0MTA3OH0.F_DX0NQMlQcBIdIXY7fhvEXbnPMsoFfMzN5JddBA6um2JXfhGn4riwsn2W0kNF-Y-Xm4JxVFHVsncmiTjaSLFg');
/*!40000 ALTER TABLE `privacy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:26:08
